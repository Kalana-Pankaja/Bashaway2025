#!/bin/bash
base64 -d<<<$1
