#!/bin/bash
rev<<<$1
