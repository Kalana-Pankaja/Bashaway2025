const { execSync } = require('child_process');

module.exports = async () => {
    console.log('\nGlobal Setup: Pulling nginx:alpine image...');
    try {
        execSync('docker pull nginx:alpine', { stdio: 'inherit' });
        console.log('Global Setup: Image pulled successfully.\n');
    } catch (error) {
        console.error('Global Setup: Failed to pull image.', error);
        throw error;
    }
};
