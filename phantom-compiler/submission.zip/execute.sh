#!/bin/bash
mkdir -p out
gcc src/main.c -o out/phantom
