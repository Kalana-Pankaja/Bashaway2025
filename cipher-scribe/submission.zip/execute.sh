#!/bin/bash
tr a-zA-Z n-za-mN-ZA-M<<<"$1"
